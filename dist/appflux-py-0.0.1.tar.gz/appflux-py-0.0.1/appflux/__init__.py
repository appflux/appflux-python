from appflux.bugflux import Bugflux
from appflux.django.appflux_exception import AppfluxException
from appflux.notify import Notify
bugflux = Bugflux()
appflux_exception = AppfluxException()
