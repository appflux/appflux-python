class Bugflux:
    def __init__(self):
        print self
